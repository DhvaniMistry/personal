package api;

public interface ScoreUpdateListener {
	public void updateScore(long score);
}
