package api;

public interface ShowDialogListener {
	public void showDialog(String dialog);
}
