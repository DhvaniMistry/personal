package hw3;


import java.util.ArrayList;
import java.util.Random;

import api.ScoreUpdateListener;
import api.ShowDialogListener;
import api.Tile;
// @author
/**
 * Class that models a game.
 */
public class ConnectGame {
	private ShowDialogListener dialogListener;
	private ScoreUpdateListener scoreListener;
	private int minn;
	private int maxx;
	private Grid num1;
	private Random ran;
	private ArrayList<Tile> indiScore = new ArrayList<>();
	private long totalScore;
	private Tile[] selectedTiles;
	private boolean statusSelect;


	/**
	 * Constructs a new ConnectGame object with given grid dimensions and minimum
	 * and maximum tile levels.
	 * 
	 * @param width  grid width
	 * @param height grid height
	 * @param min    minimum tile level
	 * @param max    maximum tile level
	 * @param rand   random number generator
	 */
	public ConnectGame(int width, int height, int min, int max, Random rand) {
		// TODO
		num1 = new Grid(width, height);
		minn = min;
		maxx = max;
		ran = rand;
		
	
	}

	/**
	 * Gets a random tile with level between minimum tile level inclusive and
	 * maximum tile level exclusive. For example, if minimum is 1 and maximum is 4,
	 * the random tile can be either 1, 2, or 3.
	 * <p>
	 * DO NOT RETURN TILES WITH MAXIMUM LEVEL
	 * 
	 * @return a tile with random level between minimum inclusive and maximum
	 *         exclusive
	 */
	public Tile getRandomTile() {
		// TODO
		int level = ran.nextInt(maxx - minn) + minn;
        return new Tile(level);
    }


	/**
	 * Regenerates the grid with all random tiles produced by getRandomTile().
	 */
	public void radomizeTiles() {
		// TODO
		//i = height
		//j = column
		for (int i = 0; i < num1.getWidth(); i++) {
	        for (int j = 0; j < num1.getHeight(); j++) {
	        	Tile tile = getRandomTile();
	            num1.setTile(tile, i, j);
	        }
	    }
	}

	/**
	 * Determines if two tiles are adjacent to each other. The may be next to each
	 * other horizontally, vertically, or diagonally.
	 * 
	 * @param t1 one of the two tiles
	 * @param t2 one of the two tiles
	 * @return true if they are next to each other horizontally, vertically, or
	 *         diagonally on the grid, false otherwise
	 */
	public boolean isAdjacent(Tile t1, Tile t2) {
		// TODO
		int t1Height = t1.getX();
	    int t1Width = t1.getY();
	    int t2Height = t2.getX();
	    int t2Width = t2.getY();

	    // Check if t1 and t2 are next to each other horizontally
	    if (t1Height == t2Height && (Math.abs(t1Width - t2Width) == 1) ) {
	        return true;
	    }

	    // Check if t1 and t2 are next to each other vertically
	    if (t1Width == t2Width && Math.abs(t1Height - t2Height) == 1) {
	        return true;
	    }

	    // Check if t1 and t2 are next to each other diagonally
	    if (Math.abs(t1Height - t2Height) == 1 && Math.abs(t1Width - t2Width) == 1) {
	        return true;
	    }

	    return false;
	
	}

	/**
	 * Indicates the user is trying to select (clicked on) a tile to start a new
	 * selection of tiles.
	 * <p>
	 * If a selection of tiles is already in progress, the method should do nothing
	 * and return false.
	 * <p>
	 * If a selection is not already in progress (this is the first tile selected),
	 * then start a new selection of tiles and return true.
	 * 
	 * @param x the column of the tile selected
	 * @param y the row of the tile selected
	 * @return true if this is the first tile selected, otherwise false
	 */
	public boolean tryFirstSelect(int x, int y) {

		// TODO
		
		Tile tile = num1.getTile(x,y);
		if(statusSelect) {
			return false;
		}

		if (!tile.isSelected()) {
			indiScore.add(tile);
			tile.setSelect(true);
			statusSelect = true;
            return true;
        } 
				return false;
		}
	

	/**
	 * Indicates the user is trying to select (mouse over) a tile to add to the
	 * selected sequence of tiles. The rules of a sequence of tiles are:
	 * 
	 * <pre>
	 * 1. The first two tiles must have the same level.
	 * 2. After the first two, each tile must have the same level or one greater than the level of the previous tile.
	 * </pre>
	 * 
	 * For example, given the sequence: 1, 1, 2, 2, 2, 3. The next selected tile
	 * could be a 3 or a 4. If the use tries to select an invalid tile, the method
	 * should do nothing. If the user selects a valid tile, the tile should be added
	 * to the list of selected tiles.
	 * 
	 * @param x the column of the tile selected
	 * @param y the row of the tile selected
	 */
	public void tryContinueSelect(int x, int y) {
		// TODO
		Tile tile = num1.getTile(x,y);
		int tileSelected = indiScore.size();
			
		if(tileSelected>0) {
		Tile tileX = indiScore.get(tileSelected - 1);

		if(tile.getX() == tileX.getX() && tile.getY() == tileX.getY()) 
		{
			unselect(x,y);
			return;
		}
		
		if(tileSelected ==1 && tileX.getLevel()!= tile.getLevel()) 
		{
			return;
		}
		
		if(tileX.getLevel()+1 == tile.getLevel() 
			|| tileX.getLevel()== tile.getLevel() 
				&& isAdjacent(tile, tileX)) 
				{
					indiScore.add(tile);
					tile.setSelect(true);
					return;
				}
		
		if (x==indiScore.get(tileSelected-2).getX() 
				&&  y ==indiScore.get(tileSelected-2).getY()) 
		{
			unselect(indiScore.get(tileSelected-1).getX(), indiScore.get(tileSelected-1).getY());
			return; 
		}
		}
		}
		//if more than one tile is selected
		
	/**
	 * Indicates the user is trying to finish selecting (click on) a sequence of
	 * tiles. If the method is not called for the last selected tile, it should do
	 * nothing and return false. Otherwise it should do the following:
	 * 
	 * <pre>
	 * 1. When the selection contains only 1 tile reset the selection and make sure all tiles selected is set to false.
	 * 2. When the selection contains more than one block:
	 *     a. Upgrade the last selected tiles with upgradeLastSelectedTile().
	 *     b. Drop all other selected tiles with dropSelected().
	 *     c. Reset the selection and make sure all tiles selected is set to false.
	 * </pre>
	 * 
	 * @param x the column of the tile selected
	 * @param y the row of the tile selected
	 * @return return false if the tile was not selected, otherwise return true
	 */
	public boolean tryFinishSelection(int x, int y) {
		// TODO
		
		if (indiScore.size() == 1) {
			unselect(x, y);
			statusSelect = false;
			return true;
		}
		Tile tile = num1.getTile(x, y);
		if (!tile.isSelected() || indiScore.get(indiScore.size() - 1) != tile) {
			return false;
		}

		upgradeLastSelectedTile();
		dropSelected();
		for (Tile tile1 : indiScore) {
			tile1.setSelect(false);
		}
		
		for(int i=0; i<indiScore.size(); i++) {
			totalScore += indiScore.get(i).getValue();
		}
		
		indiScore.clear();
		scoreListener.updateScore(totalScore);
		statusSelect = false;
		return true;
	}

	

	/**
	 * Increases the level of the last selected tile by 1 and removes that tile from
	 * the list of selected tiles. The tile itself should be set to unselected.
	 * <p>
	 * If the upgrade results in a tile that is greater than the current maximum
	 * tile level, both the minimum and maximum tile level are increased by 1. A
	 * message dialog should also be displayed with the message "New block 32,
	 * removing blocks 2". Not that the message shows tile values and not levels.
	 * Display a message is performed with dialogListener.showDialog("Hello,
	 * World!");
	 */
	public void upgradeLastSelectedTile() {
		// TODO
		Tile tile =  indiScore.get(indiScore.size()-1);
		int level = tile.getLevel() +1;
		tile.setLevel(level);
		tile.setSelect(false);
		indiScore.remove(indiScore.size()-1);
		
		if(level>maxx) {
			maxx = level;
			minn++;
			dialogListener.showDialog("New block " + (int)Math.pow(2, maxx) + ", removing blocks " + (int)Math.pow(2, minn));
			
		}
		
	}

	/**
	 * Gets the selected tiles in the form of an array. This does not mean selected
	 * tiles must be stored in this class as a array.
	 * 
	 * @return the selected tiles in the form of an array
	 */
	public Tile[] getSelectedAsArray() {
	
	    // Create a new array to hold the selected tiles

	    Tile[] selectedTiles = new Tile[indiScore.size()];
	    for(int i =0; i<indiScore.size(); i++) {
	    	selectedTiles[i]= indiScore.get(i);
	    }
		

	    return selectedTiles;
		
	}

	/**
	 * Removes all tiles of a particular level from the grid. When a tile is
	 * removed, the tiles above it drop down one spot and a new random tile is
	 * placed at the top of the grid.
	 * 
	 * @param level the level of tile to remove
	 */
	public void dropLevel(int level) {
		// TODO


			for (int col = 0; col < num1.getWidth(); col++) {
				ArrayList<Tile> newColTiles = new ArrayList<>();
				for (int row = 0; row < num1.getHeight(); row++) {
					Tile tile = num1.getTile(col, row);
					if (tile.getLevel() != level) {
						newColTiles.add(tile);
					}
				}
				int newTilesCount = num1.getHeight() - newColTiles.size();
				for (int i = 0; i < newTilesCount; i++) {
					newColTiles.add(0, getRandomTile());
				}
				for (int row = 0; row < num1.getHeight(); row++) {
					num1.setTile(newColTiles.get(row), col, row);
				}
			}
		
//		
	}

	/**
	 * Removes all selected tiles from the grid. When a tile is removed, the tiles
	 * above it drop down one spot and a new random tile is placed at the top of the
	 * grid.
	 */
	public void dropSelected() {
//		 //TODO
	
			for (Tile tile : indiScore) {
            int x = tile.getX();
            int y = tile.getY();
            for (int row = y; row > 0; row--) {
                num1.setTile(num1.getTile(x, row - 1), x, row);
            }
            num1.setTile(getRandomTile(), x, 0);
        }
   
	}
	

	/**
	 * Remove the tile from the selected tiles.
	 * 
	 * @param x column of the tile
	 * @param y row of the tile
	 */
	public void unselect(int x, int y) {
		// TODO
		//selectedTiles.remove(y,x);
		Tile tile = num1.getTile(x, y);
	    
	    // If the tile is selected, unselect it.
	    if (tile.isSelected()) {
	        tile.setSelect(false);
	        
	        // Remove the tile from the selected tiles list.
	        indiScore.remove(tile);
	    }
		
	}

	/**
	 * Gets the player's score.
	 * 
	 * @return the score
	 */
	public long getScore() {
		// TODO
		return totalScore;
	}

	/**
	 * Gets the game grid.
	 * 
	 * @return the grid
	 */
	public Grid getGrid() {
		// TODO
		return num1;
	}

	/**
	 * Gets the minimum tile level.
	 * 
	 * @return the minimum tile level
	 */
	public int getMinTileLevel() {
		// TODO
		return minn;
	}

	/**
	 * Gets the maximum tile level.
	 * 
	 * @return the maximum tile level
	 */
	public int getMaxTileLevel() {
		// TODO
		return maxx;
	}

	/**
	 * Sets the player's score.
	 * 
	 * @param score number of points
	 */
	public void setScore(long score) {
		// TODO
		totalScore= score;
	}
		
	/**
	 * Sets the game's grid.
	 * 
	 * @param grid game's grid
	 */
	public void setGrid(Grid grid) {
		// TODO
		this.num1 = grid;
	}

	/**
	 * Sets the minimum tile level.
	 * 
	 * @param minTileLevel the lowest level tile
	 */
	public void setMinTileLevel(int minTileLevel) {
		minn = minTileLevel;
	}

	/**
	 * Sets the maximum tile level.
	 * 
	 * @param maxTileLevel the highest level tile
	 */
	public void setMaxTileLevel(int maxTileLevel) {
		maxx = maxTileLevel;
	}

	/**
	 * Sets callback listeners for game events.
	 * 
	 * @param dialogListener listener for creating a user dialog
	 * @param scoreListener  listener for updating the player's score
	 */
	public void setListeners(ShowDialogListener dialogListener, ScoreUpdateListener scoreListener) {
		this.dialogListener = dialogListener;
		this.scoreListener = scoreListener;
	}

	/**
	 * Save the game to the given file path.
	 * 
	 * @param filePath location of file to save
	 */
	public void save(String filePath) {
		GameFileUtil.save(filePath, this);
	}

	/**
	 * Load the game from the given file path
	 * 
	 * @param filePath location of file to load
	 */
	public void load(String filePath) {
		GameFileUtil.load(filePath, this);
	}
}
